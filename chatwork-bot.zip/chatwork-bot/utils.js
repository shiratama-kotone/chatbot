const crypto = require('crypto');

// SHA-256ハッシュ生成
function generateHash(input) {
    return crypto.createHash('sha256').update(input).digest('hex').slice(0, 7);
}

// ID生成
function generateId(username, password) {
    return `@${generateHash(username + password)}`;
}

module.exports = {
    generateHash,
    generateId,
};
