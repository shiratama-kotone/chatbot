const express = require('express');
const crypto = require('crypto');

const app = express();
const PORT = 3000;

// 投稿データと権限の仮データ
let posts = [];
let permissions = {
    "@admin": "運営",
    "@summit": "サミット",
    "@manager": "マネージャー",
    "@speaker": "スピーカー",
    "@blueid": "青ID"
};

// JSONデータのパース
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// SHA-256でパスワードをハッシュ化
const hashPassword = (password) => {
    return crypto.createHash('sha256').update(password).digest('hex').substring(0, 7);
};

// 簡易掲示板ページ
app.get('/', (req, res) => {
    res.send(`
        <h1>掲示板</h1>
        <div>今の話題: テスト掲示板</div>
        <form method="POST" action="/post">
            <input name="name" placeholder="名前" required />
            <input name="password" type="password" placeholder="パスワード" required />
            <input name="content" placeholder="投稿内容" required />
            <button type="submit">投稿</button>
        </form>
        <div id="posts"></div>
        <script>
            async function fetchPosts() {
                const response = await fetch('/api/posts');
                const data = await response.json();
                const postsDiv = document.getElementById('posts');
                postsDiv.innerHTML = data.map(post => 
                    \`[${post.index}|${post.name}|${post.content}]\`
                ).join('<br>');
            }

            // 1秒ごとに投稿を取得
            setInterval(fetchPosts, 1000);
            fetchPosts();
        </script>
    `);
});

// 投稿取得API
app.get('/api/posts', (req, res) => {
    const postsData = posts.map((item, index) => ({
        index: index + 1,
        name: item.name,
        content: item.content
    }));
    res.json(postsData);
});

// 投稿処理
app.post('/post', (req, res) => {
    const { name, password, content } = req.body;

    if (!name || !password || !content) {
        return res.status(400).send('名前、パスワード、投稿内容はすべて必須です。');
    }

    // パスワードをハッシュ化してID生成
    const userId = `@${hashPassword(password)}`;
    const role = permissions[userId] || "青ID"; // デフォルトは青ID

    // 投稿を保存
    posts.push({
        name: `${name}${userId}`,
        content,
        role
    });

    // 投稿数が1000を超えたらリセット
    if (posts.length > 1000) {
        posts = [];
    }

    res.redirect('/');
});

// サーバー起動
app.listen(PORT, () => {
    console.log(`掲示板が http://localhost:${PORT} で動作中`);
});
