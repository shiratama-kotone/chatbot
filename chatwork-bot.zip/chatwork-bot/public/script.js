const socket = io();
const postsDiv = document.getElementById('posts');
const postBtn = document.getElementById('post-btn');
const postContent = document.getElementById('post-content');

// 投稿取得
fetch('/api/posts')
    .then((res) => res.json())
    .then((posts) => {
        posts.forEach((post) => addPost(post));
    });

// 投稿表示
function addPost({ id, username, content }) {
    const postEl = document.createElement('div');
    postEl.textContent = `[${id}|${username}] ${content}`;
    postsDiv.appendChild(postEl);
}

// 投稿リセット
function resetPosts() {
    postsDiv.innerHTML = ''; // 投稿一覧をクリア
    alert('投稿がリセットされました。投稿番号もリセットされます。');
    socket.emit('resetAcknowledged'); // サーバーに通知
}

// 新規投稿イベント
postBtn.addEventListener('click', () => {
    const content = postContent.value.trim();
    if (!content) return alert('投稿内容を入力してください！');
    fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: 'ゲスト', content }),
    }).then((res) => res.json()).then((post) => {
        addPost(post);
        postContent.value = '';
    });
});

// リアルタイム通知
socket.on('newPost', (post) => addPost(post));
socket.on('resetPosts', resetPosts); // リセット通知受信
